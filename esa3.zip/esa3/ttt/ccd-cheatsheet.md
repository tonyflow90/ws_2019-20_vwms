- Strong type checks

# Variables

- meaningful variable namse
- searchable names

> bad => setTimeout(x, 8640)
> good => const MiLLISECONDS_IN_A_DAY = 8640

- explanatory variables
- no menatal Mapping
- no unneeded context
- use default arguments

# Functions

- few arguments
- shoud do one thing
- name shoud say what they do
- one abstrcation level
- remove duplicate code
- no falgs as function parameter
- no avoid global functions
- Avoid negative conditionals
- remove dead code

# Objects & Data Structures
 - use getters & setters
 - make objects have private members

# CLasses
- classes over functions
- use methode chaining

# Testing
- Single concept per test

# Concurrency
- Use Promises, not callbacks OR Async/Await


# Error Handling
- dont ignore caught errors
- dont ignore rejected promises 

# Formatting
- consistent capitalization

# Comments
- only comment things that have bl logic